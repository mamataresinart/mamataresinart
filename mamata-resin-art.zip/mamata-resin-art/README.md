# Mamata Resin Art — Website

A single-page, no-build website (`index.html` + `images/`). No frameworks, no npm install — just open `index.html` in a browser and it works.

## 1. Before you publish — edit these placeholders

Open `index.html` and search for the word **EDIT** (Ctrl/Cmd+F). You'll find these spots:

- **WhatsApp number** — replace `91XXXXXXXXXX` (appears ~6 times: nav, hero, purchase section, contact section, footer, and the floating button, plus once inside the `<script>` as `WHATSAPP_NUMBER`) with your real number in the format `countrycode+number`, no `+`, no spaces (e.g. `919876543210`).
- **Email** — replace `hello@mamataresinart.com` with your real email (2 spots).
- **Social links** — replace the `href="#"` on the Instagram/Facebook/Pinterest icons (contact section + footer) with your real profile links.
- **Location text** — replace "Studio-based · India" with your real city/area if you'd like to share it.
- **Map** — the Contact section has a placeholder map box. To show a real Google Map, go to Google Maps → search your location → Share → Embed a map → copy the `<iframe>` code → replace the `.map-box` div with that iframe.
- **Reviews** — the 5 testimonials are realistic samples so you can see the layout. Swap in your real customer reviews before launch.

## 2. Free hosting (pick one)

I can't create hosting accounts or deploy on your behalf, but any of these get you a free live link in a few minutes:

**Netlify Drop (easiest, no account needed to preview)**
1. Go to https://app.netlify.com/drop
2. Drag the whole `mamata-resin-art` folder onto the page
3. You'll get a live `.netlify.app` link instantly. Create a free account to keep it permanently and optionally add a custom domain later.

**GitHub Pages (free, good for long-term)**
1. Create a free GitHub account and a new repository (e.g. `mamata-resin-art`)
2. Upload `index.html` and the `images` folder to the repo
3. Go to Settings → Pages → set branch to `main` / root → Save
4. Your site goes live at `https://yourusername.github.io/mamata-resin-art`

**Cloudflare Pages (free, fast)**
1. Go to https://pages.cloudflare.com → connect GitHub or drag-and-drop upload
2. Deploy — you'll get a free `.pages.dev` link

All three let you later connect a custom domain (like `mamataresinart.com`) for a small yearly domain fee if you want one.

## 3. What's inside

- Hero, About, Featured Collections, Why Choose Us, Gallery (with lightbox), Reviews, Order Process, Purchase/Pricing CTA, FAQ, Contact form (opens WhatsApp with the message pre-filled), Footer
- Fully responsive, scroll animations, glassmorphism, parallax-style floating elements, custom cursor glow on desktop
- All product photos are your uploaded images, optimized for fast loading
